#include "types.h"
#include "defs.h"
#include "x86.h"
#include "mouse.h"
#include "traps.h"

// Wait until the mouse controller is ready for us to send a packet
void 
mousewait_send(void) 
{
    while ((inb(MSSTATP) & 0x02) != 0);
    return;
}

// Wait until the mouse controller has data for us to receive
void 
mousewait_recv(void) 
{
    while ((inb(MSSTATP) & 0x01) == 0)
    return;
}

// Send a one-byte command to the mouse controller, and wait for it
// to be properly acknowledged
void 
mousecmd(uchar cmd) 
{
    mousewait_send();

    outb(MSSTATP, 0xD4); 
    mousewait_send();
    outb(MSDATAP, cmd);   
    
    mousewait_recv();

    volatile uchar ack = inb(MSDATAP);
    if (ack != 0xFA){
        cprintf("Ack Filed.\n");
    }
    return;
}

void
mouseinit(void)
{
    
    mousewait_send();
    outb(MSSTATP, 0xA8);

   
    mousewait_send();
    outb(MSSTATP, 0x20);
    mousewait_recv();
    uchar stat = (inb(MSDATAP) | 0x02);  
  
    
    mousewait_send();                   
    outb(MSSTATP, 0x60);               
    mousewait_send();
    outb(MSDATAP, stat);        

    mousecmd(0xF6);                     
    mousecmd(0xF4);                     

    ioapicenable(IRQ_MOUSE, 0);         
    cprintf("Mouse has been initialized\n");
    
    return;
}

void mouseintr(void)
{
    // Implement your code here
    volatile uchar data[3];
	for(int i = 0; i<3; ++i){
		mousewait_recv();
		data[i] = inb(MSDATAP);
	}
        
	if((data[0] & 0x01) == 0x01){
		cprintf("LEFT\n");
	}
	
	if((data[0] & 0x02) == 0x02){
		cprintf("RIGHT\n");
	}
	
	if((data[0] & 0x04) == 0x04){
		cprintf("MID\n");
	}
    return;
}